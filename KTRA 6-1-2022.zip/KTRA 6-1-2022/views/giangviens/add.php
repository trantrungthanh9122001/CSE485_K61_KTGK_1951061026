<h1>
    Thêm mới giảng viên
</h1>

<div style="color: red">
      <?php echo $error; ?>
</div>
<form method="post" action="">
    hovaten :
    <input type="text" name="hovaten" value="" />
    <br />
    ngaysinh :
    <input type="text" name="ngaysinh" value="" />
    <br />
    gioitinh :
    <input type="text" name="gioitinh" value="" />
    <br />
    trinhdo :
    <input type="text" name="trinhdo" value="" />
    <br />
    chuyenmon :
    <input type="text" name="chuyenmon" value="" />
    <br />
    hocham :
    <input type="text" name="hocham" value="" />
    <br />
    hocvi :
    <input type="text" name="hocvi" value="" />
    <br />
    coquan :
    <input type="text" name="coquan" value="" />
    <br />
    <input type="submit" name="submit" value="Save">
</form>